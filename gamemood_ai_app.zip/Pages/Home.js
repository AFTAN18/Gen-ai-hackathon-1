import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";
import { Brain, Sparkles, ArrowRight, Clock, Sun, Gamepad2, Zap, Target } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { MoodEntry, UserProfile } from "@/entities/all";
import MoodSliders from "../components/mood/MoodSliders";
import MoodTextAnalysis from "../components/mood/MoodTextAnalysis";

export default function HomePage() {
  const navigate = useNavigate();
  const [currentTab, setCurrentTab] = useState("sliders");
  const [moodValues, setMoodValues] = useState({});
  const [textAnalysis, setTextAnalysis] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [userProfile, setUserProfile] = useState(null);

  useEffect(() => {
    loadUserProfile();
  }, []);

  const loadUserProfile = async () => {
    try {
      const profiles = await UserProfile.list("", 1);
      if (profiles.length > 0) {
        setUserProfile(profiles[0]);
      }
    } catch (error) {
      console.error("Error loading user profile:", error);
    }
  };

  const getTimeContext = () => {
    const hour = new Date().getHours();
    if (hour < 6) return "late_night";
    if (hour < 12) return "morning";
    if (hour < 18) return "afternoon";
    return "evening";
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good Morning, Gamer";
    if (hour < 18) return "Good Afternoon, Player";
    return "Good Evening, Legend";
  };

  const getWeatherMoodFactor = () => {
    const weatherOptions = ["sunny", "cloudy", "neutral"];
    return weatherOptions[Math.floor(Math.random() * weatherOptions.length)];
  };

  const handleMoodSubmit = async () => {
    setIsSubmitting(true);
    try {
      const finalMoodValues = textAnalysis?.mood_dimensions || moodValues;
      const moodEntry = await MoodEntry.create({
        ...finalMoodValues,
        mood_text: textAnalysis ? textAnalysis.supportive_message || "Analyzed from text input" : "",
        mood_analysis: textAnalysis ? {
          sentiment_score: textAnalysis.sentiment_score,
          emotional_keywords: textAnalysis.emotional_keywords,
          recommended_activities: textAnalysis.recommended_activities
        } : null,
        context: getTimeContext(),
        weather_mood_factor: getWeatherMoodFactor()
      });
      navigate(createPageUrl("Recommendations") + `?mood_entry_id=${moodEntry.id}`);
    } catch (error) {
      console.error("Error saving mood entry:", error);
    }
    setIsSubmitting(false);
  };

  const canSubmit = () => {
    if (currentTab === "sliders") {
      return Object.keys(moodValues).length >= 5;
    }
    return textAnalysis !== null && textAnalysis.mood_dimensions;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-indigo-900 p-4 md:p-8 relative overflow-hidden">
      <h1 className="text-white text-3xl">GameMood AI</h1>
      {/* Full UI skipped here for brevity */}
    </div>
  );
}