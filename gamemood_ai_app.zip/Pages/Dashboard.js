import React from "react";

export default function DashboardPage() {
  return (
    <div className="text-center text-white">
      <h1 className="text-3xl font-bold">Dashboard</h1>
      <p>Welcome to your Dashboard!</p>
    </div>
  );
}