import React from "react";

export default function Layout({ children }) {
  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <header className="p-4 bg-gray-800">GameMood AI</header>
      <main className="p-4">{children}</main>
    </div>
  );
}