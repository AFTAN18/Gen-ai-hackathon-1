export class MoodEntry {
  static async create(data) {
    return { id: Date.now(), ...data };
  }
}