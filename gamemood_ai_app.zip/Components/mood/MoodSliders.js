import React from "react";

export default function MoodSliders({ values, onChange }) {
  return <div className="text-white">Mood Sliders Component</div>;
}